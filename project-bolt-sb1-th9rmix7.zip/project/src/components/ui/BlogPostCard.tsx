import React from 'react';
import { Link } from 'react-router-dom';
import { Card } from './Card';
import { BlogPost } from '../../types';

interface BlogPostCardProps {
  post: BlogPost;
}

export const BlogPostCard: React.FC<BlogPostCardProps> = ({ post }) => {
  return (
    <Card hoverEffect className="h-full flex flex-col">
      <div className="relative overflow-hidden aspect-video">
        <img
          src={post.coverImage}
          alt={post.title}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
        <div className="absolute top-3 left-3">
          <span className="bg-white dark:bg-gray-800 text-primary-600 dark:text-primary-400 text-xs font-medium px-2 py-1 rounded-md">
            {post.category}
          </span>
        </div>
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-3 space-x-3">
          <span>{post.publishedAt}</span>
          <span>•</span>
          <span>{post.readingTime}</span>
        </div>
        
        <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">
          <Link 
            to={`/blog/${post.id}`}
            className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
          >
            {post.title}
          </Link>
        </h3>
        
        <p className="text-gray-600 dark:text-gray-300 mb-4 flex-grow">
          {post.excerpt}
        </p>
        
        <Link 
          to={`/blog/${post.id}`}
          className="text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium flex items-center"
        >
          Read More
          <svg 
            className="ml-1 w-4 h-4" 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24" 
            xmlns="http://www.w3.org/2000/svg"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M14 5l7 7m0 0l-7 7m7-7H3" 
            />
          </svg>
        </Link>
      </div>
    </Card>
  );
};