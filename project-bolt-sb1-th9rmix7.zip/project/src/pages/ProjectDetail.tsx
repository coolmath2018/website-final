import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, ExternalLink, Github } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { projects } from '../data/projects';
import { Project } from '../types';

export const ProjectDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [project, setProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading from an API
    setIsLoading(true);
    setTimeout(() => {
      const foundProject = projects.find(p => p.id === id) || null;
      setProject(foundProject);
      setIsLoading(false);
    }, 300);
  }, [id]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 min-h-[70vh] flex items-center justify-center">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-64 mb-8"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full max-w-2xl mb-2.5"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full max-w-2xl mb-2.5"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full max-w-lg mb-2.5"></div>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 min-h-[70vh] flex flex-col items-center justify-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
          Project Not Found
        </h1>
        <p className="text-gray-600 dark:text-gray-300 mb-8">
          The project you're looking for doesn't exist or has been removed.
        </p>
        <Button as={Link} to="/projects" variant="primary" icon={<ArrowLeft size={16} />}>
          Back to All Projects
        </Button>
      </div>
    );
  }

  return (
    <>
      {/* Header */}
      <div className="bg-gray-900 pt-20 pb-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Link 
              to="/projects" 
              className="inline-flex items-center text-sm text-gray-300 hover:text-white mb-6 transition-colors"
            >
              <ArrowLeft size={16} className="mr-2" />
              Back to Projects
            </Link>
            <h1 className="text-4xl font-bold text-white mb-6">{project.title}</h1>
            <p className="text-xl text-gray-300 mb-8">{project.description}</p>
            
            <div className="flex flex-wrap gap-3 mb-8">
              {project.technologies.map(tech => (
                <span 
                  key={tech} 
                  className="bg-gray-800 text-gray-200 px-3 py-1 rounded-full text-sm"
                >
                  {tech}
                </span>
              ))}
            </div>
            
            <div className="flex flex-wrap gap-4">
              {project.demoUrl && (
                <Button 
                  as="a"
                  href={project.demoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  variant="primary"
                  icon={<ExternalLink size={16} />}
                >
                  Live Demo
                </Button>
              )}
              {project.repoUrl && (
                <Button 
                  as="a"
                  href={project.repoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  variant="outline"
                  className="bg-transparent border-gray-600 text-gray-300 hover:bg-gray-800"
                  icon={<Github size={16} />}
                >
                  View Code
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Project Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-4xl mx-auto">
          {/* Featured Image */}
          <div className="mb-12 rounded-lg overflow-hidden shadow-lg">
            <img 
              src={project.thumbnail} 
              alt={project.title} 
              className="w-full h-auto"
            />
          </div>
          
          {/* Project Details */}
          <div className="prose prose-lg dark:prose-invert max-w-none">
            <h2>Project Overview</h2>
            <p>{project.longDescription || project.description}</p>
            
            <h2>Technologies Used</h2>
            <ul>
              {project.technologies.map(tech => (
                <li key={tech}>{tech}</li>
              ))}
            </ul>
            
            <h2>Development Process</h2>
            <p>
              The development process for this project involved thorough planning, design, and implementation phases. Starting with user requirements and wireframes, we moved to high-fidelity designs before beginning the coding process.
            </p>
            <p>
              Throughout development, we maintained a focus on code quality, performance optimization, and accessibility to ensure the final product met all requirements and provided an excellent user experience.
            </p>
            
            {/* This would typically be pulled from actual project data */}
            <h2>Key Features</h2>
            <ul>
              <li>Responsive design for all device sizes</li>
              <li>Optimized performance with lazy loading and code splitting</li>
              <li>Accessible interface following WCAG guidelines</li>
              <li>Comprehensive test coverage for reliability</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Next/Prev Project Navigation */}
      <div className="bg-gray-50 dark:bg-gray-900/50 py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col sm:flex-row justify-between items-center">
              <Button 
                as={Link}
                to="/projects"
                variant="outline"
                className="w-full sm:w-auto mb-4 sm:mb-0"
              >
                View All Projects
              </Button>
              <div className="text-center sm:text-right text-sm text-gray-600 dark:text-gray-400">
                Project published on {project.date}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};