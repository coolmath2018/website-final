import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, Clock } from 'lucide-react';
import { blogPosts } from '../data/blogPosts';
import { BlogPost as BlogPostType } from '../types';

// Simple markdown renderer (in a production app, you'd use a proper markdown library)
const renderMarkdown = (content: string): string => {
  let html = content
    // Headers
    .replace(/^# (.*$)/gm, '<h1 class="text-3xl font-bold mt-8 mb-4">$1</h1>')
    .replace(/^## (.*$)/gm, '<h2 class="text-2xl font-bold mt-6 mb-3">$1</h2>')
    .replace(/^### (.*$)/gm, '<h3 class="text-xl font-bold mt-5 mb-2">$1</h3>')
    // Bold
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    // Italic
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    // Lists
    .replace(/^\- (.*$)/gm, '<li class="ml-6 list-disc">$1</li>')
    .replace(/^(\d+)\. (.*$)/gm, '<li class="ml-6 list-decimal">$1. $2</li>')
    // Paragraphs
    .replace(/^(?!<h|<li|<ul|<ol|<p)(.*$)/gm, '<p class="mb-4">$1</p>');
  
  // Convert consecutive list items to lists
  html = html.replace(/<li class="ml-6 list-disc">(.*?)<\/li>(\s*<li class="ml-6 list-disc">.*?<\/li>)+/gs, function(match) {
    return '<ul class="mb-4">' + match + '</ul>';
  });
  
  html = html.replace(/<li class="ml-6 list-decimal">(.*?)<\/li>(\s*<li class="ml-6 list-decimal">.*?<\/li>)+/gs, function(match) {
    return '<ol class="mb-4">' + match + '</ol>';
  });
  
  return html;
};

export const BlogPost: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [post, setPost] = useState<BlogPostType | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [relatedPosts, setRelatedPosts] = useState<BlogPostType[]>([]);

  useEffect(() => {
    // Simulate loading from an API
    setIsLoading(true);
    window.scrollTo(0, 0);
    
    setTimeout(() => {
      const foundPost = blogPosts.find(p => p.id === id) || null;
      setPost(foundPost);
      
      if (foundPost) {
        // Find related posts by category or tags
        const related = blogPosts
          .filter(p => p.id !== foundPost.id)
          .filter(p => 
            p.category === foundPost.category || 
            p.tags.some(tag => foundPost.tags.includes(tag))
          )
          .slice(0, 3);
        
        setRelatedPosts(related);
      }
      
      setIsLoading(false);
    }, 300);
  }, [id]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 min-h-[70vh] flex items-center justify-center">
        <div className="animate-pulse max-w-4xl w-full">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-8"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2.5"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2.5"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2.5"></div>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 min-h-[70vh] flex flex-col items-center justify-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
          Article Not Found
        </h1>
        <p className="text-gray-600 dark:text-gray-300 mb-8">
          The article you're looking for doesn't exist or has been removed.
        </p>
        <Link 
          to="/blog" 
          className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-base font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700"
        >
          <ArrowLeft size={16} className="mr-2" />
          Back to Blog
        </Link>
      </div>
    );
  }

  return (
    <>
      {/* Article Header */}
      <div className="pt-10 pb-8 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Link 
              to="/blog" 
              className="inline-flex items-center text-sm text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 mb-6 transition-colors"
            >
              <ArrowLeft size={16} className="mr-2" />
              Back to Blog
            </Link>
            
            <span className="inline-block bg-secondary-100 dark:bg-secondary-900 text-secondary-800 dark:text-secondary-300 text-sm font-medium px-3 py-1 rounded-full mb-4">
              {post.category}
            </span>
            
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
              {post.title}
            </h1>
            
            <div className="flex flex-wrap items-center text-sm text-gray-500 dark:text-gray-400 mb-8 gap-4">
              <div className="flex items-center">
                <Calendar size={16} className="mr-1" />
                <span>{post.publishedAt}</span>
              </div>
              <div className="flex items-center">
                <Clock size={16} className="mr-1" />
                <span>{post.readingTime}</span>
              </div>
            </div>
            
            {/* Cover Image */}
            <div className="rounded-lg overflow-hidden mb-10">
              <img 
                src={post.coverImage} 
                alt={post.title} 
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </div>
      
      {/* Article Content */}
      <article className="py-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <div 
              className="prose prose-lg dark:prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: renderMarkdown(post.content) }}
            />
            
            {/* Tags */}
            <div className="mt-12 pt-6 border-t border-gray-200 dark:border-gray-700">
              <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-3">
                Tags:
              </h4>
              <div className="flex flex-wrap gap-2">
                {post.tags.map(tag => (
                  <span 
                    key={tag} 
                    className="inline-block bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 text-xs px-3 py-1 rounded-full"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </article>
      
      {/* Related Articles */}
      {relatedPosts.length > 0 && (
        <section className="py-12 bg-gray-50 dark:bg-gray-900/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">
                Related Articles
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {relatedPosts.map(relatedPost => (
                  <Link 
                    key={relatedPost.id} 
                    to={`/blog/${relatedPost.id}`}
                    className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
                  >
                    <div className="h-40 overflow-hidden">
                      <img 
                        src={relatedPost.coverImage} 
                        alt={relatedPost.title} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-5">
                      <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                        {relatedPost.title}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {relatedPost.readingTime} • {relatedPost.category}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}
    </>
  );
};